
#include <iostream>
using std::cout;
using std::endl;

void main() {

	cout << "ergsrg" << endl;
	cout << "ergsrg" << endl;
	cout << "ergsrg" << endl;
#line 123
	cout << "ergsrg" << endl;
	cout << __FILE__ << ":" << __LINE__ << endl;
	cout << "ergsrg" << endl;

}