#define CONST1 10

#include <iostream>
using std::cout;
using std::endl;


void main() {
	//1 define const 
	cout << CONST1 << endl;
	//cout << 10 << endl;

}