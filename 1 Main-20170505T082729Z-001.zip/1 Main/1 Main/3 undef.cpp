#define A 10
#define B 20

#include <iostream>
using std::cout;
using std::endl;

void main() {

	cout << A << endl;
	cout << B << endl;

#undef B 

	cout << A << endl;
	cout << B << endl;

}