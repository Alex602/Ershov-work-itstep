#pragma once
#include <iostream>
using std::cout;
using std::endl;
void some_function() {
	cout << "some text" << endl;
}
