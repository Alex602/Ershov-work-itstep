#include "7 pragma.h"
#include "7 pragma 2.h"
void main()
{
	some_function();
}