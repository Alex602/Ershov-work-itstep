#include <iostream>
using namespace std;


#define ABC 20
void main()
{
#ifdef ABC
	cout << "abc" << endl;
#else
	cout << "123" << endl;
#endif

#if ABC > 20
	cout << "ABC > 20";
#else
	cout << "ABC <= 20";
#endif

}