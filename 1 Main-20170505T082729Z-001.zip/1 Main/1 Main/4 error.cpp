
#include <iostream>
using std::cout;
using std::endl;

void main() {

	cout << "ergsrg" << endl;
	cout << "ergsrg" << endl;
	cout << "ergsrg" << endl;
#error Some error
	cout << "ergsrg" << endl;
	cout << "ergsrg" << endl;

}