#define MACROS_SUM(x, y) ((x) + (y))

#include <iostream>
using std::cout;
using std::endl;


void main() {
	//1 define const 
	cout << MACROS_SUM(20,30) << endl;
	//cout << ((20) + (30)) << endl;

}


