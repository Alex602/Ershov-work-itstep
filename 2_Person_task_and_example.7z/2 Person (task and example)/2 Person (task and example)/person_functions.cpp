#include "person_functions.h"
void print_person(Person p){
	cout << p.name << endl;
	cout << p.adress << endl;
	cout << p.s_number << endl;
	cout << p.zipcode << endl;
	cout << p.salary << endl;
	cout << p.birthday.day << "-" << p.birthday.month<< "-" <<p.birthday.year << endl;
	cout << p.hiredate.day << "-" << p.hiredate.month<< "-" <<p.hiredate.year << endl;
	cout << p.name << endl;

}

void print_person(Person &p) {
	cout << p.name << endl;
	cout << p.adress << endl;
	cout << p.s_number << endl;
	cout << p.zipcode << endl;
	cout << p.salary << endl;
	cout << p.birthday.day << "-" << p.birthday.month << "-" << p.birthday.year << endl;
	cout << p.hiredate.day << "-" << p.hiredate.month << "-" << p.hiredate.year << endl;
	cout << p.name << endl;

}

void print_person(Person *p) {
	cout << p->name << endl;
	cout << p->adress << endl;
	cout << p->s_number << endl;
	cout << p->zipcode << endl;
	cout << p->salary << endl;
	cout << p->birthday.day << "-" << p->birthday.month << "-" << p->birthday.year << endl;
	cout << p->hiredate.day << "-" << p->hiredate.month << "-" << p->hiredate.year << endl;
	cout << p->name << endl;

}