#include "Person.h"
#pragma once
#include <iostream>
using std::cout;
using std::endl;
void print_person(Person p);
//������� ��� �������

void print_person(Person *p);
void fill_person(Person *p, char *aName, char *adress,	int zipcode, int s_number, int salary,
	             int birthday_day, char *birthday_month, int birthday_year,
				 int hiredate_day, char *hiredate_month, int hiredate_year);
Person* create_person(char *aName, char *adress,	int zipcode, int s_number, int salary,
	             int birthday_day, char *birthday_month, int birthday_year,
				 int hiredate_day, char *hiredate_month, int hiredate_year);
bool compare_person(Person *p1, Person *p2);
